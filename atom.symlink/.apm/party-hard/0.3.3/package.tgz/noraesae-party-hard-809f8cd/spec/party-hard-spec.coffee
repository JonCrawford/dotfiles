{WorkspaceView} = require 'atom'
Path = require 'path'

describe "Party Hard", ->
  beforeEach ->
    waitsForPromise ->
      atom.packages.activatePackage("party-hard")

    atom.workspaceView = new WorkspaceView
    atom.workspaceView.attachToDom()
    atom.workspace = atom.workspaceView.model

  afterEach ->
    atom.workspace.destroy()

  describe "when the party-hard:toggle event is triggered", ->
    beforeEach ->
      atom.workspaceView.openSync Path.join(__dirname, './sample.js')

    it "adds a party-hard title element in EditorViews", ->
      atom.workspaceView.eachEditorView (editorView) ->
        expect(editorView.find('#party-hard')).not.toExist()

        atom.workspaceView.trigger 'party-hard:toggle'

        runs ->
          expect(editorView.find('#party-hard')).toExist()
          atom.workspaceView.trigger 'party-hard:toggle'
          expect(editorView.find('#party-hard')).not.toExist()

    it "adds a party-hard class to EditorViews and span elements in them", ->
      atom.workspaceView.eachEditorView (editorView) ->
        expect(editorView.is('.party-hard')).toBe false
        editorView.find('span').each ->
          expect(editorView.find(@).is('.party-hard')).toBe false

        atom.workspaceView.trigger 'party-hard:toggle'

        runs ->
          expect(editorView.is('.party-hard')).toBe true
          editorView.find('span').each ->
            expect(editorView.find(@).is('.party-hard')).toBe true

          atom.workspaceView.trigger 'party-hard:toggle'

          expect(editorView.is('.party-hard')).toBe false
          editorView.find('span').each ->
            expect(editorView.find(@).is('.party-hard')).toBe false

module.exports =
  activate: ->
    atom.workspaceView.command "party-hard:toggle", => @toggle()

  isPartying: no
  toggle: ->
    if not @isPartying
      @partyHard()
      @isPartying = yes
    else
      @stopPartying()
      @isPartying = no

  partyHard: ->
    atom.workspaceView.eachEditorView (editorView) ->
      editorView.addClass 'party-hard'
      editorView.find('span').addClass 'party-hard'
      editorView.bind 'DOMNodeInserted.party-hard', (e) ->
        editorView.find(e.target).find('span').addClass 'party-hard'

      editorView.append('<div id="party-hard">KEEP<br>CALM<br>AND<br>PARTY<br>HARD</div>');

  stopPartying: ->
    atom.workspaceView.eachEditorView (editorView) ->
      editorView.removeClass 'party-hard'
      editorView.find('span').removeClass 'party-hard'
      editorView.unbind '.party-hard'

      editorView.find('#party-hard').remove()

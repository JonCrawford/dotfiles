
express = require('express')
needle = require('needle')   # simple http requests
open = require('open')       # open url in browser

# Websocket for rtm messaging through slack
WebSocket = require('ws')

class SlackClient
  instance = null
  constructor: (@clientId, @clientSecret, token=null, @port=36347) ->
    # Ensure Singleton
    if instance
      return instance
    else
      instance = this

    @app = express()
    @subscribers = []
    @startServer()

    if token? then @initClient(token) else @getTokenFromSlack()


  #################################################################
  # Helper Methods
  #################################################################

  addSubscriber: (sub) =>
    @subscribers.push sub

  apiPath: (path, data) ->
    params = ""
    params += "&#{key}=#{val}" for key, val of data
    "https://slack.com/api/#{path}#{if params? then "?#{params.substring(1)}" else ""}"

  @getInstance = =>
    return new @

  redirectUri: ->
    "http://0.0.0.0:#{@port}/oauth"


  #################################################################
  # Initialization Methods
  #################################################################

  # Initialize client to communicate with slack
  initClient: (token) =>
    @token = token
    @rtmUrl(token)

  getTokenFromSlack: =>
    open "https://slack.com/oauth/authorize?client_id=#{@clientId}&redirect_uri=#{@redirectUri()}&scope=read,post,client&state=scstate"
    @app.get '/oauth', (req, res) =>
      console.log "returned to route"
      res.send "Using code #{req.query.code} to retrieve token. <br><br>You can close this window now."

      data =
        client_id: @clientId
        client_secret: @clientSecret
        code: req.query.code
        redirect_uri: @redirectUri()

      needle.get @apiPath('oauth.access', data), (err, resp) =>
        @initClient(resp.body.access_token)

  startServer: =>
    server = @app.listen(@port, ->
      host = server.address().address
      port = server.address().port
    ).on('error', (err) =>
      console.log err
    )


  #################################################################
  # Real Time Messaging Methods
  #################################################################

  rtmUrl: (token) =>
    needle.get @apiPath('rtm.start', { token: token }), (err, resp) =>
      @team     = resp.body.team
      @ims      = resp.body.ims
      @channels = resp.body.channels
      @me       = resp.body.self
      @users    = resp.body.users
      @bots     = resp.body.bots
      @webSocket resp.body.url

  webSocket: (url) =>
    @client = new WebSocket(url)
    @client.on 'message', (message) =>
      sub(message) for sub in @subscribers


  #################################################################
  # Web API Methods
  #################################################################

  get: (method, data={}, callback) ->
    data["token"] = @token
    needle.get @apiPath(method, data), (err, resp) =>
      callback(err, resp)

  post: (method, data={}, options={}, callback) ->
    data["token"] = @token
    needle.post @apiPath(method), data, options, (err, resp) =>
      callback(err, resp)

exports.slackClient = SlackClient

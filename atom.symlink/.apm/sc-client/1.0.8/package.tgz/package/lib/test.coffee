
SlackClient = require("./app").slackClient
client = new SlackClient("xoxp-2343778742-2343778744-4814479814-224718")

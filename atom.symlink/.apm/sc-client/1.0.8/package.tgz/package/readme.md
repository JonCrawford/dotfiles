# Slack Client
Slack Client is a node module that facilitates a connection between Slack and your application. Slack Client automates the oauth flow and simplifies api calls to the [Slack API](https://api.slack.com/methods).

## Installation
```
npm install --save slack-client
```

## Usage
```
client = require("slack-client")
```

var path = require('path')
var mkdirp = require('mkdirp')
var destroy = require('dethroy')
var fs
try {
  fs = require('graceful-fs')
} catch (err) {
  fs = require('fs')
}

module.exports = function (stream, destination, done) {
  destination = path.resolve(destination)
  var dir = path.dirname(destination)
  var tmp = path.join(dir, 'tmp-' + random() + '.' + path.basename(destination))
  var finished = false
  var writer

  stream.on('error', finish)

  mkdirp(dir, function (err) {
    if (finished) return
    if (err) return finish(err)

    writer = stream.pipe(fs.createWriteStream(tmp))
      .on('finish', finish)
      .on('error', finish)
      .on('close', finish)
  })

  return function (fn) {
    done = fn
  }

  function finish(err) {
    if (finished) return
    finished = true
    // cleanup
    stream.removeListener('error', finish)
    if (writer) {
      writer.removeListener('finish', finish)
      writer.removeListener('error', finish)
      writer.removeListener('close', finish)
    }

    if (err) {
      destroy(stream)
      if (writer) destroy(writer)
      fs.unlink(tmp, function (err) {
        if (err && err.code !== 'ENOENT') return done(err)
        done()
      })
      return
    }

    fs.rename(tmp, destination, function (err) {
      if (err) return done(err)
      done(null, destination)
    })
  }
}

function random() {
  return Math.random().toString(36).slice(2)
}

1.1.0 / 2014-12-07
==================
* fix resolving `require.latest` for non semvers [#6](https://github.com/componentjs/require2/issues/6)

1.1.0 / 2014-10-28
==================

* fix `require.latest` semantic versioning sort order
* add tests

1.0.2 / 2014-10-12
==================

* provide `require.loader`
* provide `require.latest(moduleName)` to require a remote module without specify the version

1.0.1 / 2014-04-08
==================

 * fix circular dependencies

1.0.0 / 2014-04-02
==================
